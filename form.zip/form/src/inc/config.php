<?php
  session_start();
  //echo session_name() . ": " . session_id();
?>
