<?php

require (realpath("../src/inc/config.php"));
include (realpath("../src/libs/helpers.php"));
include (realpath("../src/libs/sanitization.php"));
include (realpath("../src/libs/validation.php"));