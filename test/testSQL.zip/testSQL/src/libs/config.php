<?php
session_start();

$user_id = $_SESSION['id'] ?? null;