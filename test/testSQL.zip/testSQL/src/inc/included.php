<?php

include __DIR__ . ("/../libs/config.php");
include __DIR__ . ("/../libs/validateInput.php");
include __DIR__ . ("/../libs/helpers.php");
include __DIR__ . ("/../libs/readDB.php");